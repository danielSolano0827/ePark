/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aplicacion;

/**
 *
 * Tarea #5
 * Hecho por : Kenni Gonzalez Blandon
 * Carne     : 2024201088
 * Hecho por : Daniel Solano Cordero
 * Carne     : 
 * Hecho por : Mathias Viquez Leiva
 * Carne     :
 * 
 * 
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
