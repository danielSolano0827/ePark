/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conceptos;

/**
 *
 * @author kenni
 */
public class vehiculos {
    String placa;
    String mnodelo;
    String color;
    boolean estado;

    public vehiculos(String placa, String mnodelo, String color, boolean estado) {
        this.placa = placa;
        this.mnodelo = mnodelo;
        this.color = color;
        this.estado = estado;
    }
    
    public vehiculos() {
        this.placa = "";
        this.mnodelo = "";
        this.color = "";
        this.estado = false;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getMnodelo() {
        return mnodelo;
    }

    public void setMnodelo(String mnodelo) {
        this.mnodelo = mnodelo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
    
}
