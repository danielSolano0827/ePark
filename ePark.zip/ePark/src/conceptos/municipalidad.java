/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conceptos;

import java.util.ArrayList;

/**
 *
 * @author kenni
 */
public class municipalidad {
    String nombre;
    double codigoFiscal;
    ArrayList<Integer> tarifas;

    public municipalidad(String nombre, double codigoFiscal, ArrayList<Integer> tarifas) {
        this.nombre = nombre;
        this.codigoFiscal = codigoFiscal;
        this.tarifas = tarifas;
    }
    
    public municipalidad() {
        this.nombre = "";
        this.codigoFiscal = 0;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getCodigoFiscal() {
        return codigoFiscal;
    }

    public void setCodigoFiscal(double codigoFiscal) {
        this.codigoFiscal = codigoFiscal;
    }

    public ArrayList<Integer> getTarifas() {
        return tarifas;
    }

    public void setTarifas(ArrayList<Integer> tarifas) {
        this.tarifas = tarifas;
    }
    
    
}
