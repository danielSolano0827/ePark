/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conceptos;

import java.time.LocalDate;

/**
 *
 * @author kenni
 */
public class gestorDeCobros {
    int tarifa;
    int totalPagar;
    int impuesto;
    boolean pagado;
    boolean cobroImpuesto;
    LocalDate fechaLimite;
    LocalDate fechaDePago;

    public gestorDeCobros(int tarifa, int totalPagar, int impuesto, boolean pagado, boolean cobroImpuesto, LocalDate fechaLimite, LocalDate fechaDePago) {
        this.tarifa = tarifa;
        this.totalPagar = totalPagar;
        this.impuesto = impuesto;
        this.pagado = pagado;
        this.cobroImpuesto = cobroImpuesto;
        this.fechaLimite = fechaLimite;
        this.fechaDePago = fechaDePago;
    }
    
    public gestorDeCobros() {
        this.tarifa = 0;
        this.totalPagar = 0;
        this.impuesto = 0;
        this.pagado = false;
        this.cobroImpuesto = false;
    }

    public int getTarifa() {
        return tarifa;
    }

    public void setTarifa(int tarifa) {
        this.tarifa = tarifa;
    }

    public int getTotalPagar() {
        return totalPagar;
    }

    public void setTotalPagar(int totalPagar) {
        this.totalPagar = totalPagar;
    }

    public int getImpuesto() {
        return impuesto;
    }

    public void setImpuesto(int impuesto) {
        this.impuesto = impuesto;
    }

    public boolean isPagado() {
        return pagado;
    }

    public void setPagado(boolean pagado) {
        this.pagado = pagado;
    }

    public boolean isCobroImpuesto() {
        return cobroImpuesto;
    }

    public void setCobroImpuesto(boolean cobroImpuesto) {
        this.cobroImpuesto = cobroImpuesto;
    }

    public LocalDate getFechaLimite() {
        return fechaLimite;
    }

    public void setFechaLimite(LocalDate fechaLimite) {
        this.fechaLimite = fechaLimite;
    }

    public LocalDate getFechaDePago() {
        return fechaDePago;
    }

    public void setFechaDePago(LocalDate fechaDePago) {
        this.fechaDePago = fechaDePago;
    }
    
    
    
}
