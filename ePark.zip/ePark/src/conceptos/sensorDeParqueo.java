/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conceptos;

import java.time.LocalDate;

/**
 *
 * @author kenni
 */
public class sensorDeParqueo {
    int codigoSensor;
    int zonaParqueo;
    int placa;
    LocalDate horaLlegada;
    boolean estado;
    // Metodos

    
    public sensorDeParqueo(int codigoSensor, int zonaParqueo, int placa, boolean estado, LocalDate horaLlegada) {
        this.codigoSensor = codigoSensor;
        this.zonaParqueo = zonaParqueo;
        this.placa = placa;
        this.estado = estado;
        this.horaLlegada = horaLlegada;
    }
    
    public sensorDeParqueo() {
        this.codigoSensor = 0;
        this.zonaParqueo = 0;
        this.placa = 0;
        this.estado = true;
    }
    
    public int getCodigoSensor() {
        return codigoSensor;
    }

    public void setCodigoSensor(int codigoSensor) {
        this.codigoSensor = codigoSensor;
    }

    public int getPlaca() {
        return placa;
    }

    public void setPlaca(int placa) {
        this.placa = placa;
    }

    public int getZonaParqueo() {
        return zonaParqueo;
    }

    public void setZonaParqueo(int zonaParqueo) {
        this.zonaParqueo = zonaParqueo;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public LocalDate getHoraLlegada() {
        return horaLlegada;
    }

    public void setHoraLlegada(LocalDate horaLlegada) {
        this.horaLlegada = horaLlegada;
    }
    
}
