/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aplicacion;

/**
 *
 * Tarea #5
 * Hecho por : Kenni Gonzalez Blandon
 * Carne     : 2024201088
 * Hecho por : Daniel Solano Cordero
 * Carne     : 2025069629
 * Hecho por : Mathias Viquez Leiva
 * Carne     :
 * 
 * 
 */

import conceptos.parqueos;
import conceptos.sensorDeParqueo;
import conceptos.usuarios;
import conceptos.vehiculos;
import java.time.LocalDateTime;
import java.util.Scanner;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        estacionarAuto();
    }
    
    public static void estacionarAuto(){
        
        usuarios usuario1;
        vehiculos vehiculoUsuario1;
        
        //Se crea el usuario
        usuario1 = crearUsuario();
       
        //Se crea el vehiculo
        vehiculoUsuario1 = crearVehiculo();
        
        //Se inserta el vehiculo
        usuario1.setVehiculos(vehiculoUsuario1);
        
        //Proceso para crear el objeto parqueo
        parqueos parqueoTec = new parqueos("Instituto Tecnologico de Costa Rica", "Cartago");
        parqueoTec.crearParqueo(40);
        
        parquear(parqueoTec, vehiculoUsuario1);
    }
    
    public static usuarios crearUsuario(){
        
        Scanner input = new Scanner(System.in);
        
        //Proceso para crear el objeto Usuario
        double identificacion = 0;
        String nombre;
        String apellido1;
        String apellido2;
        String correo;
        String telefono;
        boolean valido = false;
        
        System.out.println("Creando usuario...");

        while (!valido) {
            try {
                System.out.print("Ingrese su identificacion: ");
                identificacion = input.nextDouble();
                valido = true;
            } catch (Exception e) {
                System.out.println("Entrada invalida. Intente de nuevo.");
                input.next(); // limpiar el input incorrecto
            }
        }
        
        System.out.println("Ingrese su nombre:");
        nombre = input.next();
        
        System.out.println("Ingrese su primer apellido:");
        apellido1 = input.next();
        
        System.out.println("Ingrese su segundo apellido:");
        apellido2 = input.next();
        
        System.out.println("Ingrese correo:");
        correo = input.next();
        
        System.out.println("Ingrese su numero de telefono:");
        telefono = input.next();
        
        usuarios usuario1 = new usuarios(identificacion, nombre, apellido1, apellido2, correo, telefono);
        return(usuario1);
    }
    
    public static vehiculos crearVehiculo(){
        
        Scanner input = new Scanner(System.in);
        
        System.out.println("Creando vehiculo...");
        
        String placa;
        String modelo;
        String color;
        
        System.out.println("Ingrese el numero de placa de su vehiculo:");
        placa = input.next();
        
        System.out.println("Ingrese el modelo del vehiculo:");
        modelo = input.next();
        
        System.out.println("Ingrese el color del vehiculo:");
        color = input.next();
        
        vehiculos vehiculoUsuario1 = new vehiculos(placa, modelo, color, true);
        return(vehiculoUsuario1);
    }

    /**
     * Muestra un menu para parquear un vehiculo en el parqueo
     */
    public static void parquear(parqueos parqueoTec, vehiculos vehiculo) {
        
    Scanner input = new Scanner(System.in);

    boolean activo = true;

    while (activo) {
        System.out.println("\n===== MENU =====");
        System.out.println("1 - Parquear");
        System.out.println("2 - Ver parqueo");
        System.out.println("3 - Salir");
        System.out.print("Opcion: ");
        int opcion = input.nextInt();

        switch (opcion) {

            case 1:
                System.out.print("¿En que espacio desea parquear? (1 - " + parqueoTec.getSensores().length + "): ");
                int espacio = input.nextInt();

                if (espacio < 1 || espacio > parqueoTec.getSensores().length) {
                    System.out.println("Espacio invalido.");
                    break;
                }

                sensorDeParqueo sensor = parqueoTec.getSensores()[espacio - 1];

                if (sensor.isEstado()) {
                    System.out.println("El espacio " + espacio + " ya esta ocupado.");
                } else {
                    sensor.setVehiculo(vehiculo);
                    sensor.setHoraLlegada(LocalDateTime.now());
                    sensor.setEstado(true);
                    System.out.println("Vehiculo parqueado en el espacio " + espacio + ".");
                }
                break;

            case 2:
                parqueoTec.mostrarEstado();
                break;

            case 3:
                System.out.println("Saliendo...");
                activo = false;
                break;

            default:
                System.out.println("Opcion no valida.");
        }
        
        System.out.println(parqueoTec.getSensores()[1].getHoraLlegada());
    }

    input.close();
    }
}
