/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conceptos;

/**
 *
 * @author Daniel
 */
public class parqueos {
    private String nombre;
    private String localidad;
    private sensorDeParqueo[] sensores;
 
    public parqueos(String nombre, String localidad) {
        this.nombre = nombre;
        this.localidad = localidad;
        this.sensores = new sensorDeParqueo[0];
    }
 
    // Getters
    public String getNombre() { return nombre; }
    public String getLocalidad() { return localidad; }
    public sensorDeParqueo[] getSensores() { return sensores; }
 
    // Setters
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setLocalidad(String localidad) { this.localidad = localidad; }
    public void setSensores(sensorDeParqueo[] sensores) { this.sensores = sensores; }
 
    /**
     * Crea n sensores y los guarda en el arreglo.
     * codigoSensor va de 1 a n, zonaParqueo igual.
     * placa = 0, horaLlegada = null, estado = false por defecto (definido en el constructor de Sensor).
     */
    public void crearParqueo(int n) {
        sensores = new sensorDeParqueo[n];
        for (int i = 0; i < n; i++) {
            sensores[i] = new sensorDeParqueo(i+1,i+1,null,false,null);
        }
        System.out.println("Parqueo creado con " + n + " espacios.");
    }
 
    /**
     * Muestra en consola el estado actual de todos los sensores.
     */
    public void mostrarEstado() {
        System.out.println("\n--- Estado del parqueo: " + nombre + " (" + localidad + ") ---");
        if (sensores == null || sensores.length == 0) {
            System.out.println("No hay sensores configurados.");
            return;
        }
        for (sensorDeParqueo s : sensores) {
            String estado = s.isEstado() ? "Ocupado" : "Libre";
            System.out.println("Zona " + s.getZonaParqueo() + " -> " + estado);
        }
    }
}
