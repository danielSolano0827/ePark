/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aplicacion;

/**
 *
 * Tarea #5
 * Hecho por : Kenni Gonzalez Blandon
 * Carne     : 2024201088
 * Hecho por : Daniel Solano Cordero
 * Carne     : 2025069629
 * Hecho por : Mathias Viquez Leiva
 * Carne     :
 * 
 * 
 */

import Enum.tipoVehiculo;
import conceptos.app;
import conceptos.gestorDeCobros;
import conceptos.gestorParqueo;
import conceptos.parqueos;
import conceptos.sensorDeParqueo;
import conceptos.usuarios;
import conceptos.vehiculos;
import java.time.LocalDateTime;
import java.util.Scanner;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        estacionarAuto();
    }
    
    public static void estacionarAuto(){
        
        usuarios usuarioPrueba;
        vehiculos vehiculo1;
        vehiculos vehiculo2;
        vehiculos vehiculo3;
        parqueos parqueoTec;
        gestorParqueo gestorDelParqueo;
        gestorDeCobros gestorCobros;
        app aplicacion;
        
        //Se crea el usuario
        usuarioPrueba = new usuarios(303450125, "Enrique", "Castillo", "Hernandez", "prueba@gmail.com", "42356475");
        //Se crean los vehiculos
        vehiculo1 = new vehiculos("ABC123", "Toyota Corolla", "Rojo", false, tipoVehiculo.AUTOMOVIL);
        vehiculo2 = new vehiculos("MTO456", "Honda CBR", "Negro", false, tipoVehiculo.MOTOCICLETA);
        vehiculo3 = new vehiculos("CAM789", "Ford F-150", "Blanco", false, tipoVehiculo.CAMIONETA);
        //Se inserta los vehiculos al usuarios
        usuarioPrueba.setVehiculos(vehiculo1);
        usuarioPrueba.setVehiculos(vehiculo2);
        usuarioPrueba.setVehiculos(vehiculo3);
        //Se crea el parqueo con los sensores
        parqueoTec = new parqueos("Instituto Tecnologico de Costa Rica", "Cartago");
        parqueoTec.crearParqueo(40);
        //Se crea el gestorDelParqueo(gestiona sesiones) y de cobro
        gestorCobros = new gestorDeCobros(16.66, 0, 0.10, null);
        aplicacion = new app(1);
        gestorDelParqueo = new gestorParqueo(aplicacion, gestorCobros);
        //Prints de informacion
        System.out.println("Se crea un usuario simulado llamado " + usuarioPrueba.getNombre());
        System.out.println("Se crean 3 vehiculos y se asignan al usuarioPrueba");
        System.out.println("Se crea un parque simulado con " + parqueoTec.getSensores().length + " espacios.");
        
        parqueoTec.parquear(gestorDelParqueo, parqueoTec, usuarioPrueba);
    }
}
