/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conceptos;

import java.util.Date;

/**
 *
 * @author kenni
 */
public class comprobates {
    String codigoComprobante;
    Date fechaEmision;
    Date fechaDeUso;
    double montoEmitido;
    boolean impuesto;
    usuarios usuarioLigado = new usuarios();

    public comprobates(String codigoComprobante, Date fechaEmision, Date fechaDeUso, double montoEmitido, boolean impuesto) {
        this.codigoComprobante = codigoComprobante;
        this.fechaEmision = fechaEmision;
        this.fechaDeUso = fechaDeUso;
        this.montoEmitido = montoEmitido;
        this.impuesto = impuesto;
    }

    public String getCodigoComprobante() {
        return codigoComprobante;
    }

    public void setCodigoComprobante(String codigoComprobante) {
        this.codigoComprobante = codigoComprobante;
    }

    public Date getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(Date fechaEmision) {
        this.fechaEmision = fechaEmision;
    }

    public Date getFechaDeUso() {
        return fechaDeUso;
    }

    public void setFechaDeUso(Date fechaDeUso) {
        this.fechaDeUso = fechaDeUso;
    }

    public double getMontoEmitido() {
        return montoEmitido;
    }

    public void setMontoEmitido(double montoEmitido) {
        this.montoEmitido = montoEmitido;
    }

    public boolean isImpuesto() {
        return impuesto;
    }

    public void setImpuesto(boolean impuesto) {
        this.impuesto = impuesto;
    }

    public usuarios getUsuarioLigado() {
        return usuarioLigado;
    }

    public void setUsuarioLigado(usuarios usuarioLigado) {
        this.usuarioLigado = usuarioLigado;
    }
    
    
}
