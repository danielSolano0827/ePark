/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conceptos;

import java.time.Duration;
import java.time.LocalDateTime;

/**
 *
 * @author Daniel
 */
public class sesiones {
    private double tarifaPorMinuto;
    private int zona;
    private LocalDateTime horaInicio;
    private vehiculos vehiculo;
    private boolean activa;

    public sesiones(double tarifaPorMinuto, int zona, LocalDateTime horaInicio, vehiculos vehiculo) {
        this.tarifaPorMinuto = tarifaPorMinuto;
        this.zona = zona;
        this.horaInicio = horaInicio;
        this.vehiculo = vehiculo;

        this.activa = true;
    }

    public int getZona() {
        return zona;
    }

    public vehiculos getVehiculo() {
        return vehiculo;
    }

    public LocalDateTime getHoraInicio() {
        return horaInicio;
    }

    public double getTarifaPorMinuto() {
        return tarifaPorMinuto;
    }

    public void setActiva(boolean activa) {
        this.activa = activa;
    }
    
    /**
     * Calcula el total a pagar con la tarifa por minuto segun el tiempo
     */
    public double getTotalActual() {
        long minutosTranscurridos = Duration.between(horaInicio, LocalDateTime.now()).toMinutes();
        return minutosTranscurridos * tarifaPorMinuto;
    }
    
    public double finalizar(){
        double totalAPagar = this.getTotalActual();
        return totalAPagar;
    }
}
