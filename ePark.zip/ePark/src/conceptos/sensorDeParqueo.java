/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conceptos;

import java.time.LocalDateTime;

/**
 *
 * @author kenni
 */
public class sensorDeParqueo {
    int codigoSensor;
    int zonaParqueo;
    vehiculos vehiculo;
    LocalDateTime horaLlegada;
    boolean estado;
    // Metodos

    
    public sensorDeParqueo(int codigoSensor, int zonaParqueo, vehiculos vehiculo, boolean estado, LocalDateTime horaLlegada) {
        this.codigoSensor = codigoSensor;
        this.zonaParqueo = zonaParqueo;
        this.vehiculo = vehiculo;
        this.estado = estado;
        this.horaLlegada = horaLlegada;
    }
    
    public sensorDeParqueo() {
        this.codigoSensor = 0;
        this.zonaParqueo = 0;
        this.vehiculo = null;
        this.estado = true;
    }
    
    public int getCodigoSensor() {
        return codigoSensor;
    }

    public void setCodigoSensor(int codigoSensor) {
        this.codigoSensor = codigoSensor;
    }

    public vehiculos getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(vehiculos vehiculo) {
        this.vehiculo = vehiculo;
    }

    public int getZonaParqueo() {
        return zonaParqueo;
    }

    public void setZonaParqueo(int zonaParqueo) {
        this.zonaParqueo = zonaParqueo;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public LocalDateTime getHoraLlegada() {
        return horaLlegada;
    }

    public void setHoraLlegada(LocalDateTime horaLlegada) {
        this.horaLlegada = horaLlegada;
    }
    
}
